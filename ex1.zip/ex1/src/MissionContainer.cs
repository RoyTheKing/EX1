﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//name: roy segev
//id:205541428
namespace ex1new
{

    public delegate double CalcDelegate(double num);
    public class FunctionsContainer
    {
        //here we will have a dictionart wich when we give it a string we will return
        // a delgate function
        private Dictionary<string, CalcDelegate> dic = new Dictionary<string, CalcDelegate>();
        public CalcDelegate this[string index]
        {
            get
            {
                //if we have the function in the dictionary
                if (dic.ContainsKey(index))
                {
                    return dic[index];
                }
                // if we dont have the function
                // in the dictionart we are going to return 
                // an empty function
                    return val => val;
            }

            set
            {
                // the set function
                // we insert it into 
                //the dictionarry
                dic[index] = value;
            }
        }
        public List<string> getAllMissions()
        {
            //create a list and return it
            // the list contain the delcates function which 
            // the dictionary has
            List<string> lst = new List<string>(this.dic.Keys);
            return lst;
        }
    }
}
