﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//name: roy segev
//id:205541428
namespace ex1new
{
    class SingleMission : IMission
    {
        // we will have a member named caldel which will inclufe all of our caldelgate
        private CalcDelegate CalcDel;
        public SingleMission(CalcDelegate calcDel, string name)
        {
            // we have 3 member which we are going to intinlize
            // the first one is the type
            // the second one will be the name of the function
            // the third one will be the calcdelgate
            this.Type = "Single";
            this.Name = name;
            this.CalcDel = calcDel;
        }
        // here we are going to have a set and get methods
        public string Name { get; }
        public string Type { get; }
        // in the interface we van see that we will gave an event handler
        public event EventHandler<double> OnCalculate;
        // here we are going to calculate the result of the function which we juse recived
        public double Calculate(double number)
        {
            number = CalcDel(number);
            OnCalculate?.Invoke(this, number);
            return number;
        }
    }
}
