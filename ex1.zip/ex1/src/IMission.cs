﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// this will be the interface which we are going to use later.
// name:roy segev
//id:205541428
namespace ex1new
{

    public interface IMission
    {
        event EventHandler<double> OnCalculate;  

        String Name { get; }
        String Type { get; }

        double Calculate(double value);
    }
}
