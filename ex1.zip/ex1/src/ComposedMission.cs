﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//name: roy segev
//id:205541428
namespace ex1new
{
    // this will implement the imission function
    class ComposedMission  : IMission
    {
        // this will be the list which contained all of our delgates
        private LinkedList<CalcDelegate> crocs = new LinkedList<CalcDelegate>();
        public ComposedMission(string name)
        {
            this.Name = name;
            this.Type = "Composed";
         
        }
        //this will be our members 
        public string Name { get; }
        public string Type { get; }
        public ComposedMission Add(CalcDelegate calc)
        {
            crocs.AddLast(calc);
            return this;
        }
        public event EventHandler<double> OnCalculate;
        public double Calculate(double val)
        {
            foreach (CalcDelegate c in crocs)
            {
                val = c(val);
            }
            OnCalculate?.Invoke(this, val);
            return val;
        }
    }
}
